 
<?php $__env->startSection('stylesheet'); ?>
<!-- CUSTOM CSS -->
<link rel="stylesheet" href="/css/Alumni.css">
<title>Admission Info</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<br>
<div class="container" style="margin-bottom:2%;">
    <div id="heading" align="center">
        <h1 class="heading display-8">Admission Information</h1>
    </div>
    <button type="button" class="btn btn-primary" style="margin-bottom:1%;">
        Undergraduate Programs <span class="badge badge-primary"></span>
      </button>
    <br>
    <table class="table">
        <thead>
            <tr>
                <th>News</th>
                <th>File</th>
            </tr>
        </thead>
        <tbody id="myTable">
            <?php $__currentLoopData = $AdmissionInfo1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AdmissionInfo1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($AdmissionInfo1->Title); ?></td>
                <td>
                    <a href="<?php echo e(url('AdmissionPDF')); ?>/<?php echo e($AdmissionInfo1->id); ?>">view</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>



<div class="container">
    <button type="button" class="btn btn-primary" style="margin-bottom:1%;">
              Master Programs <span class="badge badge-primary"></span>
            </button>
    <br>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>News</th>
                <th>File</th>
            </tr>
        </thead>
        <tbody id="myTable">

            <?php $__currentLoopData = $AdmissionInfo2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AdmissionInfo2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($AdmissionInfo2->Title); ?></td>
                <td>
                    <a href="<?php echo e(url('AdmissionPDF')); ?>/<?php echo e($AdmissionInfo2->id); ?>">view</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>