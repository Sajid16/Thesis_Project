<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">

  </head>
  <body>
    <!-- NAVBAR BEGIN -->
    <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
      <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(Route('home')); ?>">Ahsanullah University of Science & Technology</a>
        <!-- TODO: HERE WILL GO A LOGO ALSO -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="Alumni_Login.html">Alumni</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="PDFSection/pdf.html">Vacancy</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Convocation</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Research</a>
            </li>
        </div>
    </nav>
    <!-- NAVBAR END -->

    <!-- NAV BEGIN -->
    <ul class="nav justify-content-center flex-column flex-md-row">
      <li class="nav-item">
        <a class="nav-link active" href="home.html">Home</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Academic</a>
        <div class="dropdown-menu">
          <div class="dropdown-header">Departments</div>
          <?php foreach ($departments as $departments): ?>
            <a class="dropdown-item" href="Department/department.html">-><?php echo e($departments->deptName); ?></a>
          <?php endforeach; ?>
          <!-- <a class="dropdown-item" href="Department/department.html">Computer Science & Engineering</a> -->
          <div class="dropdown-divider"></div>
          <!-- <div class="dropdown-header">Secondary Section</div> -->
          <!-- <a class="dropdown-item" href="#">Class Routine</a> -->
          <a class="dropdown-item" href="Library.html">Library Facilities</a>
          <a class="dropdown-item" href="PDFSection/pdf.html">Calender</a>
          <a class="dropdown-item" href="PDFSection/pdf.html">Tuition Fee</a>
          <a class="dropdown-item" href="PDFSection/pdf.html">Academic Rules & Info</a>
          <a class="dropdown-item" href="PDFSection/pdf.html">Examination & Grading System</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="PDFSection/pdf.html">Admission</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Administration</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="administration/administration.html">Board of Trustees</a>
          <a class="dropdown-item" href="administration/syndicate.html">Syndicate</a>
          <a class="dropdown-item" href="administration/academic_comitte.html">Academic Council</a>
          <a class="dropdown-item" href="administration/finace.html">Finace Committe</a>
          <a class="dropdown-item" href="administration/listvc.html">List of Vice-Chancellors</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="lifeataust.html">Life@AUST</a>
      </li>
    </ul>
    <!-- NAV END -->
    @yeild('index-content')
  </body>
</html>
