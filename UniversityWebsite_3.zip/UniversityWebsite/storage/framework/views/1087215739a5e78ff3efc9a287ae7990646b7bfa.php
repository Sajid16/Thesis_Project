<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Faculty Members</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" href="/css/FacultyMember.css">
  <link rel="icon" href="../images/aust-logo.jpg">
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="/web-fonts-with-css/CSS/fontawesome-all.min.css">
</head>

<body>
  <!-- NAVBAR BEGIN -->
  <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(Route('home')); ?>"><img class="home-logo" src="<?php echo e(asset('images/aust-logo.jpg')); ?>">Ahsanullah University of Science & Technology</a>
      <!-- TODO: HERE WILL GO A LOGO ALSO -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
      <span class="navbar-toggler-icon"></span>
    </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('alumni')); ?>">Alumni</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="PDFSection/pdf.html">Vacancy</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Convocation</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Research</a>
          </li>
      </div>
  </nav>
  <!-- NAVBAR END -->

  <!-- NAV BEGIN -->
  <ul class="nav justify-content-center flex-column flex-md-row">
    <li class="nav-item">
      <a class="nav-link active" href="<?php echo e(Route('home')); ?>">Home</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Academic</a>
      <div class="dropdown-menu">
        <div class="dropdown-header">Departments</div>
        <?php foreach ($homearray['departments'] as $departments): ?>
          <a class="dropdown-item" href="<?php echo e(url('department')); ?>/<?php echo e($departments->id); ?>">-><?php echo e($departments->deptName); ?></a>
        <?php endforeach; ?>
        <div class="dropdown-divider"></div>
        <!-- <div class="dropdown-header">Secondary Section</div> -->
        <!-- <a class="dropdown-item" href="#">Class Routine</a> -->
        <a class="dropdown-item" href="<?php echo e(Route('library')); ?>">Library Facilities</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Calender</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Tuition Fee</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Academic Rules & Info</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Examination & Grading System</a>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="PDFSection/pdf.html">Admission</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Administration</a>
      <div class="dropdown-menu">
        <?php foreach ($homearray['admin_menu'] as $admin_menu): ?>
          <a class="dropdown-item" href="<?php echo e(url('admin')); ?>/<?php echo e($admin_menu->id); ?>">-><?php echo e($admin_menu->adminMenuName); ?></a>
        <?php endforeach; ?>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="lifeataust.html">Life@AUST</a>
    </li>
  </ul>
  <!-- NAV END -->


  <!-- TODO: GRID FACULTY IDENTIFICATION BEGIN -->
  <!-- FACULTY TITLE  BEGIN-->

  <div class="container">
      <div class="row text-center">
          <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <?php foreach ($dept as $dept): ?>
              <h6 class="display-4 py-3 custom-undeline"><?php echo e($dept->deptName); ?></h6>
            <?php endforeach; ?>
          </div>
      </div>
  </div>
  <!-- FACULTY TITLE END-->


  <div class="container">
      <?php $__currentLoopData = $facultymember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facultymember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row py-5">
          <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 fimg">
            <img src="..\img\employee\<?php echo e($facultymember->employeeImg); ?>" class="rounded float-right text-sm-center" alt="">
          </div>

          <div class="col-12 col-sm-12 col-md-8 col-lg-8 col-xl-8">
              <h3 class="text-left"><?php echo e($facultymember->Name); ?></h3>
              <p class="text-left" id="designation"><?php echo e($facultymember->positionName); ?></p>
              <p class="text-left">Email: <?php echo e($facultymember->employeeEmail); ?></p>

              <p>
                  <a class="btn btn-primary" id="custom-button" data-toggle="collapse" href="#edu<?php echo e($facultymember->id); ?>" role="button" aria-expanded="false" aria-controls="collapseExample">Education</a>
                  <a class="btn btn-primary" id="custom-button" data-toggle="collapse" href="#exp<?php echo e($facultymember->id); ?>" role="button" aria-expanded="false" aria-controls="collapseExample">Experience</a>
                  <a class="btn btn-primary" id="custom-button" data-toggle="collapse" href="#pub<?php echo e($facultymember->id); ?>" role="button" aria-expanded="false" aria-controls="collapseExample">Publications</a>
                  <a class="btn btn-primary" id="custom-button" data-toggle="collapse" href="#aoi<?php echo e($facultymember->id); ?>" role="button" aria-expanded="false" aria-controls="collapseExample">Area of Interest</a>
              </p>
              <hr class="style9">
              <div class="collapse" id="edu<?php echo e($facultymember->id); ?>">
                  <div class="card card-body">
                      <?php echo e($facultymember->Education); ?>

                  </div>
                  <div class="collapse" id="exp<?php echo e($facultymember->id); ?>">
                      <div class="card card-body">
                          <?php echo e($facultymember->Experience); ?>

                      </div>
                      <div class="collapse" id="pub<?php echo e($facultymember->id); ?>">
                          <div class="card card-body">
                             <?php echo e($facultymember->Publications); ?>

                          </div>
                          <div class="collapse" id="aoi<?php echo e($facultymember->id); ?>">
                              <div class="card card-body">
                                <?php echo e($facultymember->AreaofInterest); ?>

                              </div>
                          </div>
                      </div>
                  </div>
                  <!-- IDENTIFICATION END -->
              </div>
          </div>
      </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>


          <!-- TODO: GRID FACULTY IDENTIFICATION END -->

          <!-- jQuery first, then Popper.js, then Bootstrap JS -->
          <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
          <script src="/bootstrap-4.0.0-dist/js/bootstrap.min.js"></script>
</body>

</html>
