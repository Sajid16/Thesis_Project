 
<?php $__env->startSection('stylesheet'); ?>
<title>Announcement PDF</title>
<link rel="stylesheet" href="<?php echo e(asset('css/Home.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/announcementPDF.css')); ?>">
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<div class="container announcement-container">
    <div class="row">
        <div class="col-sm-12">
            <div class="card announcement-card" style="">
                <div class="card-header">
                    <div class="row">
                        <img class="logo-img" src="<?php echo e(asset('images/aust-logo.jpg')); ?>" alt="Card image cap">
                    </div>
                    <div class="row">
                        <h4 style="margin:auto">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($item->newsTitle); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h4>
                    </div>
                </div>
                <div class="card announcement-card">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <object width="1000px" height="1000px" type="application/pdf" data="..\pdf\<?php echo e($value->newsPDF); ?>"></object>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>