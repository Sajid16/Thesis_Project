<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" href="/css/Alumni.css">
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="/web-fonts-with-css/CSS/fontawesome-all.min.css">
  <link rel="icon" href="../images/aust-logo.jpg">
  <title>Alumni</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

  <!-- NAVBAR BEGIN -->
  <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(Route('home')); ?>"><img class="home-logo" src="<?php echo e(asset('images/aust-logo.jpg')); ?>">Ahsanullah University of Science & Technology</a>
      <!-- TODO: HERE WILL GO A LOGO ALSO -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
      <span class="navbar-toggler-icon"></span>
    </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('alumni')); ?>">Alumni</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="PDFSection/pdf.html">Vacancy</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Convocation</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Research</a>
          </li>
      </div>
  </nav>
  <!-- NAVBAR END -->

  <!-- NAV BEGIN -->
  <ul class="nav justify-content-center flex-column flex-md-row">
    <li class="nav-item">
      <a class="nav-link active" href="<?php echo e(Route('home')); ?>">Home</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Academic</a>
      <div class="dropdown-menu">
        <div class="dropdown-header">Departments</div>
        <?php foreach ($homearray['departments'] as $departments): ?>
          <a class="dropdown-item" href="<?php echo e(url('department')); ?>/<?php echo e($departments->id); ?>">-><?php echo e($departments->deptName); ?></a>
        <?php endforeach; ?>
        <div class="dropdown-divider"></div>
        <!-- <div class="dropdown-header">Secondary Section</div> -->
        <!-- <a class="dropdown-item" href="#">Class Routine</a> -->
        <a class="dropdown-item" href="<?php echo e(Route('library')); ?>">Library Facilities</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Calender</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Tuition Fee</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Academic Rules & Info</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Examination & Grading System</a>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="PDFSection/pdf.html">Admission</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Administration</a>
      <div class="dropdown-menu">
        <?php foreach ($homearray['admin_menu'] as $admin_menu): ?>
          <a class="dropdown-item" href="<?php echo e(url('admin')); ?>/<?php echo e($admin_menu->id); ?>">-><?php echo e($admin_menu->adminMenuName); ?></a>
        <?php endforeach; ?>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="lifeataust.html">Life@AUST</a>
    </li>
  </ul>
  <!-- NAV END -->

<br>
<div class="container">
  <div id="heading" align="center">
    <h1 class="heading display-8">Alumni List</h1>
  </div>
  <p align="center">Type something in the input field to search the table for names , id , passing year or emails:</p>
  <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>Student ID</th>
        <th>Name</th>
        <th>Department</th>
        <th>CGPA</th>
        <th>Email</th>
        <th>Passing Year</th>
        <th>Current Working Position</th>
      </tr>
    </thead>
    <tbody id="myTable">
      <?php foreach ($alumni as $alumni): ?>
        <tr>
          <td><?php echo e($alumni->studentID); ?></td>
          <td><?php echo e($alumni->Name); ?></td>
          <td><?php echo e($alumni->deptName); ?></td>
          <td><?php echo e($alumni->cgpa); ?></td>
          <td><?php echo e($alumni->studentEmail); ?></td>
          <td><?php echo e($alumni->passingYear); ?></td>
          <td><?php echo e($alumni->currentPosition); ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

;

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

</body>
</html>

<?php echo $__env->make('Footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>