<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" href="/css/Department.css">
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="/web-fonts-with-css/CSS/fontawesome-all.min.css">
  <link rel="icon" href="../images/aust-logo.jpg">
  <title>Department</title>
</head>

<body>

  <!-- NAVBAR BEGIN -->
  <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(Route('home')); ?>"><img class="home-logo" src="<?php echo e(asset('images/aust-logo.jpg')); ?>">Ahsanullah University of Science & Technology</a>
      <!-- TODO: HERE WILL GO A LOGO ALSO -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
      <span class="navbar-toggler-icon"></span>
    </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('alumni')); ?>">Alumni</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="PDFSection/pdf.html">Vacancy</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Convocation</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Research</a>
          </li>
      </div>
  </nav>
  <!-- NAVBAR END -->

  <!-- NAV BEGIN -->
  <ul class="nav justify-content-center flex-column flex-md-row">
    <li class="nav-item">
      <a class="nav-link active" href="<?php echo e(Route('home')); ?>">Home</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Academic</a>
      <div class="dropdown-menu">
        <div class="dropdown-header">Departments</div>
        <?php foreach ($homearray['departments'] as $departments): ?>
          <a class="dropdown-item" href="<?php echo e(url('department')); ?>/<?php echo e($departments->id); ?>">-><?php echo e($departments->deptName); ?></a>
        <?php endforeach; ?>
        <div class="dropdown-divider"></div>
        <!-- <div class="dropdown-header">Secondary Section</div> -->
        <!-- <a class="dropdown-item" href="#">Class Routine</a> -->
        <a class="dropdown-item" href="<?php echo e(Route('library')); ?>">Library Facilities</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Calender</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Tuition Fee</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Academic Rules & Info</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Examination & Grading System</a>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="PDFSection/pdf.html">Admission</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Administration</a>
      <div class="dropdown-menu">
        <?php foreach ($homearray['admin_menu'] as $admin_menu): ?>
          <a class="dropdown-item" href="<?php echo e(url('admin')); ?>/<?php echo e($admin_menu->id); ?>">-><?php echo e($admin_menu->adminMenuName); ?></a>
        <?php endforeach; ?>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="lifeataust.html">Life@AUST</a>
    </li>
  </ul>
  <!-- NAV END -->


  <!-- DEPARTMENTAL MENU STARTS HERE -->
  <div class="container-fluid">
    <!-- <a href="<?php echo e(Route('home')); ?>"><img class="home-logo" src="<?php echo e(asset('img/logo.png')); ?>" float="left"></a> -->
    <div id="heading" align="center">
      <h1 class="heading display-4">Department Of</h1>
      <!-- <h3 class="heading display-8">Computer Science and Engineering</h3> -->
      <?php foreach ($departmentarray['dept'] as $dept): ?>
        <h3 class="heading display-8"><?php echo e($dept->deptName); ?></h3>
        <!-- <h3 class="heading display-8">Computer Science and Engineering</h3> -->
      <?php endforeach; ?>
    </div>
    <div class="row">
      <div class="col-sm-12 col-md-3 col-lg-3 col-xl-3">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="collapse navbar-collapse dept_menu" id="navbarSupportedContent">
            <ul class="navbar flex-column mr-auto" class="list-group" style="list-style:none;" align: "left";>
              <li class="dept nav-item active" class="list-group-item">
                <a class="dept nav-link" href="<?php echo e(url('facultymember')); ?>/<?php echo e($dept->id); ?>">Faculty members<span class="sr-only">(current)</span></a>
              </li>
              <li class="dept nav-item" class="list-group-item">
                <a class="dept nav-link" href="labfacilities.html">Lab facilities</a>
              </li>
              <li class="dept nav-item dropdown">
                <a class="dept nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Courses
        </a>
                <div class="dept dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dept dropdown-item" href="pdf.html">1st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">1st year 2st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">2st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">2st year 2st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">3st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">3st year 2st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">4st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">4st year 2st semester</a>
                </div>
              </li>
              <li class="dept nav-item dropdown">
                <a class="dept nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Class Routine
        </a>
                <div class="dept dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dept dropdown-item" href="pdf.html">1st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">1st year 2st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">2st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">2st year 2st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">3st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">3st year 2st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">4st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">4st year 2st semester</a>
                </div>
              </li>
              <li class="dept nav-item dropdown">
                <a class="dept nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Lab Manual
        </a>
                <div class="dept dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dept dropdown-item" href="pdf.html">1st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">1st year 2st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">2st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">2st year 2st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">3st year 1st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">3st year 2st semester</a>
                  <a class="dept dropdown-item" href="pdf.html">4st year 1st semester</a>
                  <a class="dept dept dropdown-item" href="pdf.html">4st year 2st semester</a>
                </div>
              </li>
              <?php foreach ($departmentarray['dept'] as $dept): ?>
                <li class="dept nav-item" class="list-group-item">
                    <a class="dept nav-link" href="<?php echo e(url('aboutdepartment')); ?>/<?php echo e($dept->id); ?>">Know Your Department</a>
                </li>
              <?php endforeach; ?>
            </ul>
          </div>
        </nav>
      </div>

      <!-- DEPARTMENTAL MENU ENDS HERE -->

      <!-- CAROUSEL STARTS HERE -->

      <div class="col-sm-12 col-md-6 col-lg-6 col-xl-6">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="d-block w-100" src="../img/main_bg.png" alt="First slide">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="../img/bg_img_2.png" alt="Second slide">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="../img/bg_img_3.png" alt="Third slide">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
        </div>
      </div>

      <!-- CAROUSEL ENDS HERE -->

      <!-- NEWS AND ANNOUNCEMENT STARTS HERE -->

      <div class="col-sm-12 col-md-3 col-lg-3 col-xl-3">
        <div class="announcement">
          <a href="#"><h1 class="display-4">News & Announcement</h1></a>
        </div>
        <div class="table-wrapper-scroll-y">
        <table class="table table-hover">
          <tbody>
            <?php foreach ($departmentarray['deptnews'] as $deptnews): ?>
              <tr>
                <td><?php echo e($deptnews->postDate); ?></td>
                <td><a href="#" class="news"><?php echo e($deptnews->newsTitle); ?></a></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    </div>

    <!-- NEWS AND ANNOUNCEMENT ENDS HERE -->

    <!-- DEPARTMENTAL EVENTS STARTS HERE-->
    <h5 class="display-4 events" color="#1E0026;">EVENTS</h5>
    <hr class="seperator1" color="#1E0026;">
    <div class="row">
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
        <div class="card" style="width: 18rem;">
          <img class="card-img-top" src="/images/up-event-1.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">AUST NCPC Prize Giving Ceremony</h5>
            <p class="card-text">Here we will appear a little bit description of departmental events only.</p>
            <a href="event.html" class="btn btn-primary">Read More</a>
          </div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
        <div class="card" style="width: 18rem;">
          <img class="card-img-top" src="/images/up-event-1.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">AUST NCPC Prize Giving Ceremony</h5>
            <p class="card-text">Here we will appear a little bit description of departmental events only.</p>
            <a href="event.html" class="btn btn-primary">Read More</a>
          </div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
        <div class="card" style="width: 18rem;">
          <img class="card-img-top" src="/images/up-event-1.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">AUST NCPC Prize Giving Ceremony</h5>
            <p class="card-text">Here we will appear a little bit description of departmental events only.</p>
            <a href="event.html" class="btn btn-primary">Read More</a>
          </div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3">
        <div class="card" style="width: 18rem;">
          <img class="card-img-top" src="/images/up-event-1.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">AUST NCPC Prize Giving Ceremony</h5>
            <p class="card-text">Here we will appear a little bit description of departmental events only.</p>
            <a href="event.html" class="btn btn-primary">Read More</a>
          </div>
        </div>
      </div>
    </div>

    <!-- DEPARTMENTAL EVENTS ENDS HERE -->


    <!-- MESSAGE FROM DEPT HEAD -->
    <h5 class="display-4 message" color="#1E0026;">MESSAGE</h5>
    <hr class="seperator1" color="#1E0026;">
    <?php foreach ($departmentarray['depthead'] as $depthead): ?>
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 msg_part">
          <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-3 col-xl-3">
              <img src="..\img\depthead\<?php echo e($depthead->headImg); ?>" alt="file not found" width="170" height="205">
            </div>
            <div class="col-sm-12 col-md-6 col-lg-3 col-xl-3 msg_part1">
              <h6><?php echo e($depthead->Name); ?></h6>
              <h6>Departmental Head</h6>
              <hr color="#1E0026;">
            </div>
            <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 msg_part2">
              <p class="lead"><?php echo e($depthead->headMsg); ?></p>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>


  


  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>

<?php echo $__env->make('Footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>