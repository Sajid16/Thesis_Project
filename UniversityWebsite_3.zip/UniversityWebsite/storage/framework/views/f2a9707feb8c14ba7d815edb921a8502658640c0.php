 
<?php $__env->startSection('stylesheet'); ?>
<!-- CUSTOM CSS -->
<link rel="stylesheet" href="/css/Alumni.css">
<title>Alumni</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<br>
<div class="container">
  <div id="heading" align="center">
    <h1 class="heading display-8">Alumni List</h1>
  </div>
  <p align="center">Type something in the input field to search the table for names , id , passing year or emails:</p>
  <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>Student ID</th>
        <th>Name</th>
        <th>Department</th>
        <th>CGPA</th>
        <th>Email</th>
        <th>Passing Year</th>
        <th>Current Working Position</th>
      </tr>
    </thead>
    <tbody id="myTable">
      <?php foreach ($alumni as $alumni): ?>
      <tr>
        <td><?php echo e($alumni->studentID); ?></td>
        <td><?php echo e($alumni->Name); ?></td>
        <td><?php echo e($alumni->deptName); ?></td>
        <td><?php echo e($alumni->cgpa); ?></td>
        <td><?php echo e($alumni->studentEmail); ?></td>
        <td><?php echo e($alumni->passingYear); ?></td>
        <td><?php echo e($alumni->currentPosition); ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>


<script>
  $(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>