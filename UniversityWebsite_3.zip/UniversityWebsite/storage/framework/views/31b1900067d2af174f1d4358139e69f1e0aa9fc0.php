
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
  </head>
  <body>
    <!-- FOOTER BEGIN -->
    <div class="container-fluid custom-footer">
      <div class="row text-center">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <h4 class="py-3">Ahsanullah University of Science and Technology</h4>
          <!-- <hr class="light"> -->
          <p>141 & 142, Love Road, Tejgaon Industrial Area, Dhaka-1208.</p>
          <p>Tel. (8802) 8870422, Ext. 107, 114, Fax : (8802) 8870417-18</p>
          <p>Email : info@aust.edu, regr@aust.edu</p>
          <hr class="light">
        </div>
      </div>
    </div>
    <!-- FOOTER END -->
  </body>
</html>
