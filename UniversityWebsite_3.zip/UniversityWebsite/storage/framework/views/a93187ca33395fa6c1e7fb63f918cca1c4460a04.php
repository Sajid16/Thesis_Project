<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" href="/css/Library.css">
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="/web-fonts-with-css/CSS/fontawesome-all.min.css">
  <link rel="icon" href="../images/aust-logo.jpg">
  <title>Ahsanullah University of Science and Technology</title>
</head>

<body>

  <!-- NAVBAR BEGIN -->
  <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(Route('home')); ?>"><img class="home-logo" src="<?php echo e(asset('images/aust-logo.jpg')); ?>">Ahsanullah University of Science & Technology</a>

      <!-- TODO: HERE WILL GO A LOGO ALSO -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
      <span class="navbar-toggler-icon"></span>
    </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('alumni')); ?>">Alumni</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="PDFSection/pdf.html">Vacancy</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Convocation</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Research</a>
          </li>
      </div>
  </nav>
  <!-- NAVBAR END -->

  <!-- NAV BEGIN -->
  <ul class="nav justify-content-center flex-column flex-md-row">
    <li class="nav-item">
      <a class="nav-link active" href="<?php echo e(Route('home')); ?>">Home</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Academic</a>
      <div class="dropdown-menu">
        <div class="dropdown-header">Departments</div>
        <?php foreach ($homearray['departments'] as $departments): ?>
          <a class="dropdown-item" href="<?php echo e(url('department')); ?>/<?php echo e($departments->id); ?>">-><?php echo e($departments->deptName); ?></a>
        <?php endforeach; ?>
        <div class="dropdown-divider"></div>
        <!-- <div class="dropdown-header">Secondary Section</div> -->
        <!-- <a class="dropdown-item" href="#">Class Routine</a> -->
        <a class="dropdown-item" href="<?php echo e(Route('library')); ?>">Library Facilities</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Calender</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Tuition Fee</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Academic Rules & Info</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Examination & Grading System</a>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="PDFSection/pdf.html">Admission</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Administration</a>
      <div class="dropdown-menu">
        <?php foreach ($homearray['admin_menu'] as $admin_menu): ?>
          <a class="dropdown-item" href="<?php echo e(url('admin')); ?>/<?php echo e($admin_menu->id); ?>">-><?php echo e($admin_menu->adminMenuName); ?></a>
        <?php endforeach; ?>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="lifeataust.html">Life@AUST</a>
    </li>
  </ul>
  <!-- NAV END -->



  <!-- HEADING PART -->
  <div class="container">
    <div id="heading" align="center">
      <h1 class="heading display-8">Library Facilities</h1>
    </div>
  </div>
  <!-- HEADING PART ENDS -->

  <!-- CAROUSEL STARTS HERE -->

  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
               </li>
              <!-- <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li> -->
            </ol>
             <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="..\img\main_bg.png" alt="...">
              </div>
              <!-- <div class="carousel-item">
                <img src="..\img\main_bg.png" alt="...">
                <div class="carousel-caption d-none d-md-block">
                  <h5>Hello</h5>
                  <p>AUST</p>
                </div>
              </div> -->
              <!-- <div class="carousel-item">
                <img src="..\img\main_bg.png" alt="...">
                <div class="carousel-caption d-none d-md-block">
                  <h5>Hello</h5>
                  <p>AUST</p>
                </div>
              </div> -->
            </div>
          </div>

      </div>
    </div>
  </div>

  <!-- CAROUSEL ENDS HERE -->

  <!-- ABOUT STARTS HERE -->

  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div id="heading" align="center">
        <?php foreach ($libraryarray['librarydet'] as $librarydet): ?>
          <h1 class="heading display-4"><?php echo e($librarydet->detailsHead); ?></h1>
          <hr color="black">
          <p class="lead dept_desc"><?php echo e($librarydet->description); ?></p>
        <?php endforeach; ?>
      </div>
      </div>
    </div>
  </div>

  <!-- ABOUT ENDS HERE -->

  <!-- FOOTER BEGIN -->
  <div class="container-fluid custom-footer">
    <div class="row text-center">
      <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <h4 class="py-3">Ahsanullah University of Science and Technology</h4>
        <!-- <hr class="light"> -->
        <p>141 & 142, Love Road, Tejgaon Industrial Area, Dhaka-1208.</p>
        <p>Tel. (8802) 8870422, Ext. 107, 114, Fax : (8802) 8870417-18</p>
        <p>Email : info@aust.edu, regr@aust.edu</p>
        <hr class="light">
      </div>
    </div>
  </div>

  <!-- FOOTER END -->

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>
