 
<?php $__env->startSection('stylesheet'); ?>
<title>Event</title>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/event.css')); ?>">
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<div class="container title-container">
    <div class="row welcome text-center">
        <div class="col-sm-12">
            <h3>
                <?php $__currentLoopData = $arr['query1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($key->eventTitle); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h3>
        </div>
    </div>
</div>
<!--Event Date -->
<div class="container date-container">
    <div class="row welcome text-center">
        <div class="col-sm-12">
            <p>
                <?php $__currentLoopData = $arr['query1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($key->date); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        </div>
    </div>
</div>


<!-- Event Image Slide -->
<div class="container carousel-container">
    <div class="row">
        <div class="col-sm-12">
            <div id="mycarousel" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <!--<li data-target="#mycarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#mycarousel" data-slide-to="1"></li>
                    <li data-target="#mycarousel" data-slide-to="2"></li> -->
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img id="eventslide1" src=" ..\images\<?php echo e($key->eventImg); ?>">
                    </div>
                </div>
                <!--<a class="carousel-control-prev" href="#mycarousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#mycarousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a> -->
            </div>
        </div>
    </div>
</div>
<!-- Event Description -->
<div class="container card-container">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-6 col-lg-8 col-xl-8">
            <div class="card event-card">
                <div class="card-header">Description</div>
                <div class="card-body">
                    <h5 class="card-title" id="eventName">
                        <?php $__currentLoopData = $arr['query1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($key->eventTitle); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </h5>
                    <p class="card-text" id="eventDescription">
                        <?php $__currentLoopData = $arr['query1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $key->description ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
            </div>
        </div>
        <!-- Important Notice -->
        <div class=" col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4">
            <div class="card table-card">
                <div class="card-header">Important Notice</div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <!-- <th scope="col">#</th> -->
                                <th scope="col">Important News</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <?php $__currentLoopData = $arr['query2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($key->impNotice); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Downloadable Links -->
            <div class="card required-file" id="reqFiles">
                <div class="card-header">Required Files</div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <!-- <th scope="col">File Name </th> -->
                                <th scope="col">file</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <!-- <th scope="row">notice</th> -->
                                <td>
                                    <?php $__currentLoopData = $arr['query2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" class="btn btn-link"><?php echo e($key->file); ?></button> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Registration Links -->
<div class="container">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-6 col-lg-8 col-xl-8">
            <div class="card reg-card">
                <div class="card-header">Registration Links :</div>
                <div class="card-body" id="regLinks">
                    <?php $__currentLoopData = $arr['query1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($key->regLink); ?>"><?php echo e($key->regLink); ?></a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>