 
<?php $__env->startSection('stylesheet'); ?>
<!-- CUSTOM CSS -->
<link rel="stylesheet" href="/css/FacultyMember.css">
<title>Faculty Members</title>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<!-- TODO: GRID FACULTY IDENTIFICATION BEGIN -->
<!-- FACULTY TITLE  BEGIN-->

<div class="container">
  <div class="row text-center">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
      <?php foreach ($dept as $dept): ?>
      <h6 class="display-4 py-3 custom-undeline"><?php echo e($dept->deptName); ?></h6>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<!-- FACULTY TITLE END-->


<div class="container">
  <?php $__currentLoopData = $facultymember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facultymember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="row py-5">
    <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 fimg">
      <img src="..\img\employee\<?php echo e($facultymember->employeeImg); ?>" class="rounded float-right text-sm-center" alt="">
    </div>

    <div class="col-12 col-sm-12 col-md-8 col-lg-8 col-xl-8">
      <h3 class="text-left"><?php echo e($facultymember->Name); ?></h3>
      <p class="text-left" id="designation"><?php echo e($facultymember->positionName); ?></p>
      <p class="text-left">Email: <?php echo e($facultymember->employeeEmail); ?></p>

      <p>
        <a class="btn btn-primary" id="custom-button" data-toggle="collapse" href="#edu<?php echo e($facultymember->id); ?>" role="button" aria-expanded="false"
          aria-controls="collapseExample">Education</a>
        <a class="btn btn-primary" id="custom-button" data-toggle="collapse" href="#exp<?php echo e($facultymember->id); ?>" role="button" aria-expanded="false"
          aria-controls="collapseExample">Experience</a>
        <a class="btn btn-primary" id="custom-button" data-toggle="collapse" href="#pub<?php echo e($facultymember->id); ?>" role="button" aria-expanded="false"
          aria-controls="collapseExample">Publications</a>
        <a class="btn btn-primary" id="custom-button" data-toggle="collapse" href="#aoi<?php echo e($facultymember->id); ?>" role="button" aria-expanded="false"
          aria-controls="collapseExample">Area of Interest</a>
      </p>
      <hr class="style9">
      <div class="collapse" id="edu<?php echo e($facultymember->id); ?>">
        <div class="card card-body">
          <?php echo e($facultymember->Education); ?>

        </div>
        <div class="collapse" id="exp<?php echo e($facultymember->id); ?>">
          <div class="card card-body">
            <?php echo $facultymember->Experience ?>

          </div>
          <div class="collapse" id="pub<?php echo e($facultymember->id); ?>">
            <div class="card card-body">
              <?php echo e($facultymember->Publications); ?>

            </div>
            <div class="collapse" id="aoi<?php echo e($facultymember->id); ?>">
              <div class="card card-body">
                <?php echo e($facultymember->AreaofInterest); ?>

              </div>
            </div>
          </div>
        </div>
        <!-- IDENTIFICATION END -->
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>