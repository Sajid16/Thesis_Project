<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="/web-fonts-with-css/CSS/fontawesome-all.min.css">
  <link rel="icon" href="../images/aust-logo.jpg">
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" href="/css/Home.css">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

  <title>Ahsanullah University of Science and Technology</title>
</head>

<body>

  <!-- NAVBAR BEGIN -->
  <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(Route('home')); ?>"><img class="home-logo" src="<?php echo e(asset('images/aust-logo.jpg')); ?>">Ahsanullah University of Science & Technology</a>
      <!-- TODO: HERE WILL GO A LOGO ALSO -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
      <span class="navbar-toggler-icon"></span>
    </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('alumni')); ?>">Alumni</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="PDFSection/pdf.html">Vacancy</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Convocation</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Research</a>
          </li>
      </div>
  </nav>
  <!-- NAVBAR END -->

  <!-- NAV BEGIN -->
  <ul class="nav justify-content-center flex-column flex-md-row">
    <li class="nav-item">
      <a class="nav-link active" href="<?php echo e(Route('home')); ?>">Home</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Academic</a>
      <div class="dropdown-menu">
        <div class="dropdown-header">Departments</div>
        <?php foreach ($homearray['departments'] as $departments): ?>
          <a class="dropdown-item" href="<?php echo e(url('department')); ?>/<?php echo e($departments->id); ?>">-><?php echo e($departments->deptName); ?></a>
        <?php endforeach; ?>
        <div class="dropdown-divider"></div>
        <!-- <div class="dropdown-header">Secondary Section</div> -->
        <!-- <a class="dropdown-item" href="#">Class Routine</a> -->
        <a class="dropdown-item" href="<?php echo e(Route('library')); ?>">Library Facilities</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Calender</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Tuition Fee</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Academic Rules & Info</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Examination & Grading System</a>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="PDFSection/pdf.html">Admission</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Administration</a>
      <div class="dropdown-menu">
        <?php foreach ($homearray['admin_menu'] as $admin_menu): ?>
          <a class="dropdown-item" href="<?php echo e(url('admin')); ?>/<?php echo e($admin_menu->id); ?>">-><?php echo e($admin_menu->adminMenuName); ?></a>
        <?php endforeach; ?>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="lifeataust.html">Life@AUST</a>
    </li>
  </ul>
  <!-- NAV END -->


  <!-- CAROUSEL BEGIN -->
  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="d-block w-100" src="/images/main_bg.png" alt="First slide">
        <div class="carousel-caption d-none d-md-block custom-carousel-caption">
          <h5 class="display-4">Hacathon Starting Soon!</h5>
          <p class="lead custom-p-description">Join with your team, achieve the biggest hacathon ever in AUST.</p>
          <button type="button" class="btn btn-outline-light btn-lg">View More</button>
          <button type="button" class="btn btn-primary btn-lg">Join Now</button>
        </div>
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="/images/main_bg.png" alt="First slide">
        <div class="carousel-caption d-none d-md-block custom-carousel-caption">
          <h5 class="display-4">Get Ready With Your Convocation Hat!</h5>
          <p class="lead custom-p-description">Convocation registration deadline 1 March, 2018</p>
          <button type="button" class="btn btn-outline-light btn-lg">View More</button>
          <button type="button" class="btn btn-primary btn-lg">Register Now</button>
        </div>
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="/images/main_bg.png" alt="First slide">
        <div class="carousel-caption d-none d-md-block custom-carousel-caption">
          <h5 class="display-4">AUST Alumni Day Out!</h5>
          <p class="lead custom-p-description">Complete your fee, and get ready for the blast</p>
          <button type="button" class="btn btn-outline-light btn-lg">View More</button>
          <button type="button" class="btn btn-primary btn-lg">Register Now</button>
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>
  <!-- CAROUSEL END -->

  <!-- GRID BEGIN -->
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-12 col-md-12 col-xl-8">
        <a href="#"><h3 class="py-4" style="color: #422978;">UPCOMING EVENTS</h3></a>
        <div id="carouselEventControl" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img id="eventImage" class="d-block w-100" src="images/up-event-1.png" alt="First slide">
              <div class="carousel-caption d-none d-md-block custom-carousel-caption">
                <h5 class="display-4">AUST PC 2018</h5>
                <h6>MAY 20, 1018</h6>
                <p class="lead">Organized by CSE</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="images/up-event-2.png" alt="Second slide">
              <div class="carousel-caption d-none d-md-block custom-carousel-caption">
                <h5 class="display-4">ICPC Prize Ceremony</h5>
                <h6>AUG 20, 1018</h6>
                <p class="lead">Organized by CSE</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="images/up-event-3.png" alt="Third slide">
              <div class="carousel-caption d-none d-md-block custom-carousel-caption">
                <h5 class="display-4">IEEE Robotics Award 2018</h5>
                <h6>Dec 12, 1018</h6>
                <p class="lead">Organized by EEE</p>
              </div>
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselEventControl" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
          <a class="carousel-control-next" href="#carouselEventControl" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
        </div>
      </div>
      <div class="col-sm-12 col-md-12 col-xl-4">
        <a href="#"><h3 class="py-4" style="color: #422978;">ANNOUNCEMENT</h3></a>
        <div class="table-wrapper-scroll-y">
        <table class="table table-hover">
          <tbody>
            <?php foreach ($homearray['news'] as $news): ?>
              <tr>
                <td><?php echo e($news->postDate); ?></td>
                <td><a href="#" class="news"><?php echo e($news->newsTitle); ?></a></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      </div>
      <!-- GRID END -->

      <!-- ACHIEVEMENT GRID BEGIN -->

      <div class="container-fluid padding">
        <div class="row welcome text-center">
          <div class="col-12">
            <a href="#"><h3 class="py-4" style="color: #422978;">ACHIEVEMENTS</h3></a>
          </div>
        </div>
      </div>

      <div class="container-fluid">
          <div class="row">
            <?php foreach ($homearray['achievement'] as $achievement): ?>
            <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
              <div class="card">
                <img class="card-img-top" src="..\img\achievement\<?php echo e($achievement->titleImg); ?>" alt="image">
                <div class="card-body">
                  <h4 class="card-title"><?php echo e($achievement->Title); ?></h4>
                  <!-- Button trigger modal -->
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#des<?php echo e($achievement->id); ?>">
                    Read More
                  </button>
                </div>
              </div>
            </div>

            <!-- Modal -->
            <div class="modal fade" id="des<?php echo e($achievement->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e($achievement->Title); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>

                  <div class="acvimg">
                    <img src="..\img\achievement\<?php echo e($achievement->titleImg); ?>" class="img-rounded" alt="Image not found">
                  </div>

                  <div class="modal-body">
                    <?php echo e($achievement->Description); ?>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
      </div>

      <!-- <script>
        $(document).ready(function(){
          $('.card').hover(
            function(){
              $(this).animate({
                marginTop:"-=1%",
              },200);
            },

            function(){
              $(this).animate({
                marginTop:"0%",
              },200);
            }
          );
        });
      </script> -->

      <!-- ACHIEVEMENT GRID END -->

      <!-- QUOTES CAROUSEL SLIDER BEGIN -->
      <div class="container-fluid py-5">
        <div class="row">
          <div class="col-sm-12">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
              <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
              </ol>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img id="hiddenImage" class="d-block w-100" src="images/bg_img_3.png" alt="First slide">
                  <div class="carousel-caption d-none d-sm-block">
                    <img class="py-5 vc-image" src="images/vc-image.png"  alt="">
                    <h5>MESSAGE FROM VC</h5>
                    <p>Message from our honourable vc and ohers honourable person,s will appear here </p>
                  </div>
                </div>
                <div class="carousel-item">
                  <img id="hiddenImage" class="d-block w-100" src="images/bg_img_3.png" alt="Second slide">
                  <div class="carousel-caption d-none d-sm-block">
                    <img class="py-5 vc-image" src="images/vc-image.png"  alt="">
                    <h5>MESSAGE FROM VC</h5>
                    <p>Message from our honourable vc and others honourable person, will appear here.</p>
                  </div>
                </div>
                <div class="carousel-item">
                  <img id="hiddenImage" class="d-block w-100" src="images/bg_img_3.png" alt="Third slide">
                  <div class="carousel-caption d-none d-sm-block">
                    <img class="py-5 vc-image" src="images/vc-image.png"  alt="">
                    <h5>MESSAGE FROM VC</h5>
                    <p>Message from our honourable vc and others honourable person, will appear here.</p>
                  </div>
                </div>
              </div>
              <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
              <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
            </div>
          </div>
        </div>
      </div>
      <!-- QUOTES CAROUSEL SLIDER END -->

        ;

      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
      <script src="/bootstrap-4.0.0-dist/js/bootstrap.min.js"></script>
</body>

</html>

<?php echo $__env->make('Footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>