 
<?php $__env->startSection('stylesheet'); ?>
<title>Event List</title>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/eventList.css')); ?>">
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<!-- Event List Title Started From here -->
<div class="container-flex event-container">
    <div class="row welcome text-center">
        <div class="col-sm-12">
        <h2>Event List <img src="<?php echo e(asset('images/list.png')); ?>" alt="list"></h2>
        </div>
    </div>
</div>
<!-- Event List Title Closed From here -->

<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <table class="table event-table">
                <thead>
                    <tr>
                        <th scope="col" style="color: darkorange">#</th>
                        <th scope="col" style="color: darkorange">Events Title</th>
                        <th scope="col" style="color: darkorange">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($value->id); ?></th>
                        <td><a href="<?php echo e(url('event')); ?>/<?php echo e($value->id); ?>"><?php echo e($value->eventTitle); ?></a></td>
                        <td><?php echo e($value->date); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>
            <?php echo $data->links();; ?>

        </div>
    </div>
</div>
<!--<div class="container event-paging-container">
    <div class="row">
        <div class="col-sm-12">
            <nav aria-label="...">
                <ul class="pagination event-pagination">
                    <li class="page-item disabled">
                        <a class="page-link" href="#" tabindex="-1">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#"><?php echo e($data->links()); ?></a></li>
                    <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </nav>

        </div>
    </div>
</div> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>