<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="/web-fonts-with-css/CSS/fontawesome-all.min.css">
  <link rel="icon" href="<?php echo e(asset('images/aust-logo.jpg')); ?>">
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
    crossorigin="anonymous"></script>
  <?php echo $__env->yieldContent('stylesheet'); ?>


</head>

<body>

  <!-- NAVBAR BEGIN -->
  <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(Route('home')); ?>"><img class="home-logo" src="<?php echo e(asset('images/aust-logo.jpg')); ?>">Ahsanullah University of Science & Technology</a>
      <!-- TODO: HERE WILL GO A LOGO ALSO -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
      <span class="navbar-toggler-icon"></span>
    </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('alumni')); ?>"><img src="<?php echo e(asset('images/alumni.png')); ?>" style="margin-left:5%;">Alumni</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('GeneralPDF')); ?>/vacancy"><img src="<?php echo e(asset('images/vacancy.png')); ?>" style="margin-right:5%;;">Vacancy</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('convo')); ?>"><img src="<?php echo e(asset('images/graduate-cap.png')); ?>" style="margin-right:5%;">Convocation</a>
          </li>
          
      </div>
  </nav>
  <!-- NAVBAR END -->

  <!-- NAV BEGIN -->
  <ul class="nav justify-content-center flex-column flex-md-row">
    <li class="nav-item">
      <a class="nav-link active" href="<?php echo e(Route('home')); ?>">Home</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Academic</a>
      <div class="dropdown-menu">
        <div class="dropdown-header dropdown-header-text">Departments</div>
        <?php foreach ($homearray['departments'] as $departments): ?>
        <a class="dropdown-item" href="<?php echo e(url('department')); ?>/<?php echo e($departments->id); ?>" style="font-weight:500"><?php echo e($departments->deptName); ?></a>
        <?php endforeach; ?>
        <div class="dropdown-divider"></div>
        <!-- <div class="dropdown-header">Secondary Section</div> -->
        <!-- <a class="dropdown-item" href="#">Class Routine</a> -->
        <a class="dropdown-item" href="<?php echo e(Route('library')); ?>">Library Facilities</a>
        <a class="dropdown-item" href="<?php echo e(url('GeneralPDF')); ?>/calendar">Calender</a>
        <a class="dropdown-item" href="<?php echo e(Route('tuitionfees')); ?>">Tuition Fee</a>
        <a class="dropdown-item" href="<?php echo e(url('GeneralPDF')); ?>/rules">Academic Rules & Info</a>
        <a class="dropdown-item" href="<?php echo e(url('GeneralPDF')); ?>/grading">Examination & Grading System</a>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(url('Admission')); ?>">Admission</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Administration</a>
      <div class="dropdown-menu">
        <?php foreach ($homearray['admin_menu'] as $admin_menu): ?>
        <a class="dropdown-item" href="<?php echo e(url('admin')); ?>/<?php echo e($admin_menu->id); ?>"><?php echo e($admin_menu->adminMenuName); ?></a>
        <?php endforeach; ?>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(url('aust-life')); ?>">Life@AUST</a>
    </li>
  </ul>
  <!-- NAV END -->
  <?php echo $__env->yieldContent('content'); ?>
  <!-- FOOTER BEGIN -->
  
  <div class="container-fluid custom-footer">
    <div class="row text-center">
      <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <h4 class="py-3">Ahsanullah University of Science and Technology</h4>
        <p>141 & 142, Love Road, Tejgaon Industrial Area, Dhaka-1208.</p>
        <p>Tel. (8802) 8870422, Ext. 107, 114, Fax : (8802) 8870417-18</p>
        <p>Email : info@aust.edu, regr@aust.edu</p>
        <hr class="light">
      </div>
    </div>
  </div>
  <!-- Footer -->
  

  <!-- FOOTER END -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="/bootstrap-4.0.0-dist/js/bootstrap.min.js"></script>
</body>

</html>