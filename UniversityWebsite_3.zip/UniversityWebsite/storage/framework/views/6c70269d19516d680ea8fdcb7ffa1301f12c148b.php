<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Administration</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="/bootstrap-4.0.0-dist/css/bootstrap.min.css">
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" href="/css/FacultyMember.css">
  <link rel="icon" href="../images/aust-logo.jpg">
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="/web-fonts-with-css/CSS/fontawesome-all.min.css">
</head>

<body>
  <!-- NAVBAR BEGIN -->
  <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(Route('home')); ?>"><img class="home-logo" src="<?php echo e(asset('images/aust-logo.jpg')); ?>">Ahsanullah University of Science & Technology</a>

      <!-- TODO: HERE WILL GO A LOGO ALSO -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
      <span class="navbar-toggler-icon"></span>
    </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('alumni')); ?>">Alumni</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="PDFSection/pdf.html">Vacancy</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Convocation</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Research</a>
          </li>
      </div>
  </nav>
  <!-- NAVBAR END -->

  <!-- NAV BEGIN -->
  <ul class="nav justify-content-center flex-column flex-md-row">
    <li class="nav-item">
      <a class="nav-link active" href="<?php echo e(Route('home')); ?>">Home</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Academic</a>
      <div class="dropdown-menu">
        <div class="dropdown-header">Departments</div>
        <?php foreach ($homearray['departments'] as $departments): ?>
          <a class="dropdown-item" href="<?php echo e(url('department')); ?>/<?php echo e($departments->id); ?>">-><?php echo e($departments->deptName); ?></a>
        <?php endforeach; ?>
        <div class="dropdown-divider"></div>
        <!-- <div class="dropdown-header">Secondary Section</div> -->
        <!-- <a class="dropdown-item" href="#">Class Routine</a> -->
        <a class="dropdown-item" href="Library.html">Library Facilities</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Calender</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Tuition Fee</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Academic Rules & Info</a>
        <a class="dropdown-item" href="PDFSection/pdf.html">Examination & Grading System</a>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="PDFSection/pdf.html">Admission</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Administration</a>
      <div class="dropdown-menu">
        <?php foreach ($homearray['admin_menu'] as $admin_menu): ?>
          <a class="dropdown-item" href="<?php echo e(url('admin')); ?>/<?php echo e($admin_menu->id); ?>">-><?php echo e($admin_menu->adminMenuName); ?></a>
        <?php endforeach; ?>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="lifeataust.html">Life@AUST</a>
    </li>
  </ul>
  <!-- NAV END -->


  <!-- TODO: GRID FACULTY IDENTIFICATION BEGIN -->
  <!-- FACULTY TITLE  BEGIN-->

    <div class="container">
      <div class="row text-center">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <?php foreach ($homearray['adminName'] as $adminName): ?>
            <h6 class="display-4 py-3 custom-undeline">List of <?php echo e($adminName->adminMenuName); ?></h6>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <!-- FACULTY TITLE END-->

    <div class="container">
      <?php foreach ($adminMember as $adminMember): ?>
      <div class="row py-5">
        <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
            <img src="..\img\employee\<?php echo e($adminMember->employeeImg); ?>" class="rounded float-right text-sm-center" alt="" height="150px">
        </div>

        <div class="col-12 col-sm-12 col-md-8 col-lg-8 col-xl-8">
          <h3 class="text-left"><?php echo e($adminMember->Name); ?></h3>
          <p class="text-left" id="education"><?php echo e($adminMember->positionName); ?></p>
          <p class="text-left">Email: <?php echo e($adminMember->employeeEmail); ?></p>
          <p class="text-left">Duration: <?php echo e($adminMember->Experience); ?></p>

          <!-- <p>
            <a class="btn btn-primary" data-toggle="collapse" href="#exp<?php echo e($adminMember->id); ?>"   role="button" aria-expanded="false" aria-controls="collapseExample">
              Experience
            </a>
          </p>
          <hr class="style9">
          <div class="collapse" id="exp<?php echo e($adminMember->id); ?>">
              <div class="card card-body">
                <?php echo e($adminMember->Experience); ?>

              </div>
          </div> -->
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
          <!-- IDENTIFICATION END -->


          <!-- TODO: GRID FACULTY IDENTIFICATION END -->

          <!-- jQuery first, then Popper.js, then Bootstrap JS -->
          <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
          <script src="/bootstrap-4.0.0-dist/js/bootstrap.min.js"></script>
</body>

</html>
