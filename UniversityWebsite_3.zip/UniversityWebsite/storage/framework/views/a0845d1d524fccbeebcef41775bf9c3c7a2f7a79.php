 
<?php $__env->startSection('stylesheet'); ?>
<title>Announcement</title>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/announcement1.css')); ?>">
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<div class="container announcement-container">
    <div class="row">
        <div class="col-sm-12">
            <div class="card announcement-card" style="width:50%">
                <div class="card-header">
                    <div class="row">
                        <img class="logo-img" src="<?php echo e(asset('images/aust-logo.jpg')); ?>" alt="Card image cap">
                    </div>
                    <div class="row">
                        <h4 style="margin:auto;">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($item->newsTitle); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h4>
                    </div>
                </div>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="card-img-top" src="..\images\<?php echo e($value->newsImg); ?>" alt="Card image cap">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <div class="card-body">
                <p class="card-text"><?php echo $value->description ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>