<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class semesters extends Model
{
    //
}
